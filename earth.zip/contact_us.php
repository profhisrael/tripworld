<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>::-Contact Us-::</title>

<link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<?php include "Dheader_view.php"; ?>
<div class="container desktop">
    <h1 align="center" style="font-family:Grenze Gotisch;"><b>Contact US</b></h1>




<p align="center" style="font-size:16px;">You can contact us at:<a href="mailto:contact@tripworld.co">contact@tripworld.co</a>
    <b>OR</b> visit <a href="https://tripworld.co">https://tripworld.co</a> to view our legal details. <p>


    </div>
   <?php include "Dfooter_view.php"; ?>
    
    <div class="mobileView">
	<div class="container">
        <div class="mobNav"><a href="javascript:void(0);" class="mobNavClick"><span></span><span></span><span></span></a></div>
        <div class="navigation">
        	<div class="navClose"><img src="images/close.png" alt=""></div>
        	<div class="navLogo"><img src="images/mobLogo.png" alt=""></div>
            <ul>
                 <li><a href="index.html">Home</a></li>
            	
            <hr>
                <li><a href="#">Login</a></li>
                 <li><a href="https://www.old.tripworld.earth/BETASIGNUP/">Registration</a></li><hr>
                 <li><a href="how_it_works.php">How It Works</a></li>
                <li><a href="our_promise.php">Our Promise</a></li>
                 <li><a href="our_partnership.php">Our Partnership</a></li><hr>
                <li><a href="faqs.php">FAQ</a></li><hr>
                    <li><a href="contact_us.php">Contact</a></li>
                <li><a href="policy.php">Privacy Policy</a></li>
            </ul>
        </div>
       
        <div class="mobLogo"><img src="images/mobLogo.png" alt=""></div>
        
        
        <br><br><br>
        
        <div class="container">
    <h1 align="center" style="font-family:Grenze Gotisch;"><b>Contact US</b></h1>
        <br>
        <p align="center" style="font-size:16px;">You can contact us at:<a href="mailto:contact@tripworld.co">contact@tripworld.co</a>
    <b>OR</b> visit <a href="https://tripworld.co">https://tripworld.co</a> to view our legal details. <p>


    </div>
        
        
        
        
            
        
        
            
    </div>
    <div class="overlay"></div>
    <div class="mobFoot"><img src="images/mobileFoot.png" alt=""></div>
</div>

  

</body>

</html>
