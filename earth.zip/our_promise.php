<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>::-Our Promise-::</title>

<link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>


    
    <div class="mobileView">
	<div class="container">
        <div class="mobNav"><a href="javascript:void(0);" class="mobNavClick"><span></span><span></span><span></span></a></div>
        <div class="navigation">
        	<div class="navClose"><img src="images/close.png" alt=""></div>
        	<div class="navLogo"><img src="images/mobLogo.png" alt=""></div>
            <ul>
                <li><a href="index.html">Home</a></li>
            	
            <hr>
                <li><a href="#">Login</a></li>
                 <li><a href="https://www.old.tripworld.earth/BETASIGNUP/">Registration</a></li><hr>
                 <li><a href="how_it_works.php">How It Works</a></li>
                <li><a href="our_promise.php">Our Promise</a></li>
                 <li><a href="our_partnership.php">Our Partnership</a></li><hr>
                <li><a href="faqs.php">FAQ</a></li><hr>
                    <li><a href="contact_us.php">Contact</a></li>
                <li><a href="policy.php">Privacy Policy</a></li>
            </ul>
        </div>
       
        <div class="mobLogo"><img src="images/mobLogo.png" alt=""></div>

      
<div class="keyPrinciples">
        	<div class="keyPrinceHeading orangeHeading"><span>Our key principles</span></div>
        	<div class="row">
            	<div class="col-md-4">
                	<div class="keyPrincipleBlock">
                    	<div class="keyPrinceImg"><img src="images/homeSec3Img1.jpg" alt=""></div>
                        <div class="keyPrinceCont">
                        	<div class="orangeHeading">Easy Setup</div>
                            <div class="runningTxt">Just search from our website to do good <br>Four (4) clicks registration for email monetization</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                	<div class="keyPrincipleBlock">
                    	<div class="keyPrinceImg"><img src="images/homeSec3Img2.jpg" alt=""></div>
                        <div class="keyPrinceCont">
                        	<div class="orangeHeading">High Privacy</div>
                            <div class="runningTxt">We don't log or keep any of your search <br>We don't store or analyse any of your emails <br>All data is immediately deleted from our servers</div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                	<div class="keyPrincipleBlock">
                    	<div class="keyPrinceImg"><img src="images/homeSec3Img3.jpg" alt=""></div>
                        <div class="keyPrinceCont">
                        	<div class="orangeHeading">Trees or Cash</div>
                            <div class="runningTxt">Using your Dashboard choose What to do with your money generated from emails <br>Automatic good when search with us.</div>
                        </div></div></div></div></div>
    </div>
    <div class="overlay"></div>
    <div class="mobFoot"><img src="images/mobileFoot.png" alt=""></div>
</div>

  <script src="../../ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>	
      <script src="js/jquery.min.js"></script>
<script src="js/custom.js"></script>
  

</body>

</html>
