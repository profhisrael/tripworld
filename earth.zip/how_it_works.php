<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>::-How it Works-::</title>

<link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>


    
    <div class="mobileView">
	<div class="container">
        <div class="mobNav"><a href="javascript:void(0);" class="mobNavClick"><span></span><span></span><span></span></a></div>
        <div class="navigation">
        	<div class="navClose"><img src="images/close.png" alt=""></div>
        	<div class="navLogo"><img src="images/mobLogo.png" alt=""></div>
            <ul>
                <li><a href="index.html">Home</a></li>
            	<hr>
            
                <li><a href="#">Login</a></li>
                 <li><a href="https://www.old.tripworld.earth/BETASIGNUP/">Registration</a></li><hr>
                 <li><a href="how_it_works.php">How It Works</a></li>
                <li><a href="our_promise.php">Our Promise</a></li>
                 <li><a href="our_partnership.php">Our Partnership</a></li><hr>
                <li><a href="faqs.php">FAQ</a></li><hr>
                    <li><a href="contact_us.php">Contact</a></li>
                <li><a href="policy.php">Privacy Policy</a></li>
            </ul>
        </div>
       
        <div class="mobLogo"><img src="images/mobLogo.png" alt=""></div>

      
<div class="midWrap">
	<div class="container">
    	<div class="homeSec1">        	
        	<div class="row">
            	<div class="col-md-6">
                	<div class="homeSec1Img"><img src="images/homeSecImg1.png" alt=""></div>
                </div>
       <div class="col-md-6">
                	<div class="homeSec1Cont">
                    	<div class="orangeHeading" align="center">Just Register a Free
Account with us!</div>
                        <div class="runningTxt" align="justify">When you Search using TripEarth (Powered by Bing), 50% of our revenues are reserved for Tree planting. 
When you Read your everyday emails (Gmail), you get paid. An non-intrusive high quality ad is placed below your received emails.
You can then decide to keep the money, plant trees or split.</div>
                    </div>
                </div>
            </div></div></div>
    
        
        </div>
            
        
        
            
    </div>
    <div class="overlay"></div>
    <div class="mobFoot"><img src="images/mobileFoot.png" alt=""></div>
</div>

  <script src="../../ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>	
      <script src="js/jquery.min.js"></script>
<script src="js/custom.js"></script>
  

</body>

</html>
