<div class="mobileView">
	<div class="container">
        <div class="mobNav"><a href="javascript:void(0);" class="mobNavClick"><span></span><span></span><span></span></a></div>
        <div class="navigation">
        	<div class="navClose"><img src="images/close.png" alt=""></div>
        	<div class="navLogo"><img src="images/mobLogo.png" alt=""></div>
            <ul>
            	<li><a href="faqs.php">FAQ</a></li>
                <li><a href="contact_us.php">Contact</a></li>
                <li><a href="policy.php">Privacy Policy</a></li>
                <li><a href="#">Login</a></li>
                 <li><a href="https://www.tripworld.earth/betasignup/">Registration</a></li>
            </ul>
        </div>
        <div class="mobLogo"><img src="images/mobLogo.png" alt=""></div>