<header>
	<div class="container desktop">
    	<div class="header">
    	<div class="row">
        	<div class="col-md-6">
                <div class="headerLeft"><div class=""><a href="index.html"><img src="images/logo.png" height="80%" width="60%" alt=""></a></div>
                    
                </div>
            </div>
         
            <div class="col-md-6">
                <a href="index.html"> <img src="images/home2.png" width="10%" height="5%" style="color:red; background-color:white;" ></a>
            	<div class="headerRight">
                    
                    <ul>
                    	<li><a href="">Sign In</a></li>
                        <li><a href="https://www.tripworld.earth/betasignup/">Register</a></li>
                        <li><a href="#"><span></span><span></span><span></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
        </div>
    </div>
</header>