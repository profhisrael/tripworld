<footer>
	<div class="footerWrap desktop">
	<div class="footerTop">
    	<div class="footerTopBg"><img src="images/footNavBg.png" alt=""></div>
        <div class="footerNav">
        	<ul>
            	<li><a href="faqs.php">FAQ</a></li>
                <li><a href="policy.php">Privacy</a></li>
                <li><a href="contact_us.php">Contact</a></li>
            </ul>
        </div>
    </div>
    
    <div class="footerSocial">
    	<ul>
        	<li><a href="https://www.facebook.com/TripWorldTripEarth"><img src="images/fbIcon.png" alt=""></a></li>
            <li><a href="#"><img src="images/twitterIcon.png" alt=""></a></li>
            <li><a href="https://www.instagram.com/tripworld.earth/"><img src="images/instaIcon.png" alt=""></a></li>
        </ul>
    </div>
    
    <div class="footerBot">© 2020 www.tripearth.com | All Rights Reserved</div>
    </div>
</footer>
<script src="../../ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>	
      <script src="js/jquery.min.js"></script>
<script src="js/custom.js"></script>